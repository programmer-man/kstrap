<option value="">Please Select</option>
<option value="US" <?php echo $country == "US" ? "selected" : "" ?>>United States</option>
<option value="CA" <?php echo $country == "CA" ? "selected" : "" ?>>Canada</option>
<option value="UK" <?php echo $country == "UK" ? "selected" : "" ?>>United Kingdom</option>
<option value="AU" <?php echo $country == "AU" ? "selected" : "" ?>>Australia</option>
<option value="AF" <?php echo $country == "AF" ? "selected" : "" ?>>Afghanistan</option>
<option value="AL" <?php echo $country == "AL" ? "selected" : "" ?>>Albania</option>
<option value="DZ" <?php echo $country == "DZ" ? "selected" : "" ?>>Algeria</option>
<option value="AS" <?php echo $country == "AS" ? "selected" : "" ?>>American Samoa</option>
<option value="AD" <?php echo $country == "AD" ? "selected" : "" ?>>Andorra</option>
<option value="AO" <?php echo $country == "AO" ? "selected" : "" ?>>Angola</option>
<option value="AI" <?php echo $country == "AI" ? "selected" : "" ?>>Anguilla</option>
<option value="AQ" <?php echo $country == "AQ" ? "selected" : "" ?>>Antarctica</option>
<option value="AG" <?php echo $country == "AG" ? "selected" : "" ?>>Antigua and Barbuda</option>
<option value="AR" <?php echo $country == "AR" ? "selected" : "" ?>>Argentina</option>
<option value="AM" <?php echo $country == "AM" ? "selected" : "" ?>>Armenia</option>
<option value="AW" <?php echo $country == "AW" ? "selected" : "" ?>>Aruba</option>
<option value="AT" <?php echo $country == "AT" ? "selected" : "" ?>>Austria</option>
<option value="AZ" <?php echo $country == "AZ" ? "selected" : "" ?>>Azerbaijan</option>
<option value="BS" <?php echo $country == "BS" ? "selected" : "" ?>>Bahamas</option>
<option value="BH" <?php echo $country == "BH" ? "selected" : "" ?>>Bahrain</option>
<option value="BD" <?php echo $country == "BD" ? "selected" : "" ?>>Bangladesh</option>
<option value="BB" <?php echo $country == "BB" ? "selected" : "" ?>>Barbados</option>
<option value="BY" <?php echo $country == "BY" ? "selected" : "" ?>>Belarus</option>
<option value="BE" <?php echo $country == "BE" ? "selected" : "" ?>>Belgium</option>
<option value="BZ" <?php echo $country == "BZ" ? "selected" : "" ?>>Belize</option>
<option value="BJ" <?php echo $country == "BJ" ? "selected" : "" ?>>Benin</option>
<option value="BM" <?php echo $country == "BM" ? "selected" : "" ?>>Bermuda</option>
<option value="BT" <?php echo $country == "BT" ? "selected" : "" ?>>Bhutan</option>
<option value="BO" <?php echo $country == "BO" ? "selected" : "" ?>>Bolivia</option>
<option value="BA" <?php echo $country == "BA" ? "selected" : "" ?>>Bosnia and Herzegovina</option>
<option value="BW" <?php echo $country == "BW" ? "selected" : "" ?>>Botswana</option>
<option value="BR" <?php echo $country == "BR" ? "selected" : "" ?>>Brazil</option>
<option value="BN" <?php echo $country == "BN" ? "selected" : "" ?>>Brunei Darussalam</option>
<option value="BG" <?php echo $country == "BG" ? "selected" : "" ?>>Bulgaria</option>
<option value="BF" <?php echo $country == "BF" ? "selected" : "" ?>>Burkina Faso</option>
<option value="BI" <?php echo $country == "BI" ? "selected" : "" ?>>Burundi</option>
<option value="KH" <?php echo $country == "KH" ? "selected" : "" ?>>Cambodia</option>
<option value="CM" <?php echo $country == "CM" ? "selected" : "" ?>>Cameroon</option>
<option value="CV" <?php echo $country == "CV" ? "selected" : "" ?>>Cape Verde</option>
<option value="KY" <?php echo $country == "KY" ? "selected" : "" ?>>Cayman Islands</option>
<option value="CF" <?php echo $country == "CF" ? "selected" : "" ?>>Central African Republic</option>
<option value="TD" <?php echo $country == "TD" ? "selected" : "" ?>>Chad</option>
<option value="CL" <?php echo $country == "CL" ? "selected" : "" ?>>Chile</option>
<option value="CN" <?php echo $country == "CN" ? "selected" : "" ?>>China</option>
<option value="CX" <?php echo $country == "CX" ? "selected" : "" ?>>Christmas Island</option>
<option value="CC" <?php echo $country == "CC" ? "selected" : "" ?>>Cocos (Keeling) Islands</option>
<option value="CO" <?php echo $country == "CO" ? "selected" : "" ?>>Colombia</option>
<option value="KM" <?php echo $country == "KM" ? "selected" : "" ?>>Comoros</option>
<option value="CG" <?php echo $country == "CG" ? "selected" : "" ?>>Congo</option>
<option value="CD" <?php echo $country == "CD" ? "selected" : "" ?>>Congo, The Democratic Republic of the
</option>
<option value="CK" <?php echo $country == "CK" ? "selected" : "" ?>>Cook Islands</option>
<option value="CR" <?php echo $country == "CR" ? "selected" : "" ?>>Costa Rica</option>
<option value="CI" <?php echo $country == "CI" ? "selected" : "" ?>>Cote D`Ivoire</option>
<option value="HR" <?php echo $country == "HR" ? "selected" : "" ?>>Croatia</option>
<option value="CY" <?php echo $country == "CY" ? "selected" : "" ?>>Cyprus</option>
<option value="CZ" <?php echo $country == "CZ" ? "selected" : "" ?>>Czech Republic</option>
<option value="DK" <?php echo $country == "DK" ? "selected" : "" ?>>Denmark</option>
<option value="DJ" <?php echo $country == "DJ" ? "selected" : "" ?>>Djibouti</option>
<option value="DM" <?php echo $country == "DM" ? "selected" : "" ?>>Dominica</option>
<option value="DO" <?php echo $country == "DO" ? "selected" : "" ?>>Dominican Republic</option>
<option value="EC" <?php echo $country == "EC" ? "selected" : "" ?>>Ecuador</option>
<option value="EG" <?php echo $country == "EG" ? "selected" : "" ?>>Egypt</option>
<option value="SV" <?php echo $country == "SV" ? "selected" : "" ?>>El Salvador</option>
<option value="GQ" <?php echo $country == "GQ" ? "selected" : "" ?>>Equatorial Guinea</option>
<option value="ER" <?php echo $country == "ER" ? "selected" : "" ?>>Eritrea</option>
<option value="EE" <?php echo $country == "EE" ? "selected" : "" ?>>Estonia</option>
<option value="ET" <?php echo $country == "ET" ? "selected" : "" ?>>Ethiopia</option>
<option value="FK" <?php echo $country == "FK" ? "selected" : "" ?>>Falkland Islands (Malvinas)</option>
<option value="FO" <?php echo $country == "FO" ? "selected" : "" ?>>Faroe Islands</option>
<option value="FJ" <?php echo $country == "FJ" ? "selected" : "" ?>>Fiji</option>
<option value="FI" <?php echo $country == "FI" ? "selected" : "" ?>>Finland</option>
<option value="FR" <?php echo $country == "FR" ? "selected" : "" ?>>France</option>
<option value="GF" <?php echo $country == "GF" ? "selected" : "" ?>>French Guiana</option>
<option value="PF" <?php echo $country == "PF" ? "selected" : "" ?>>French Polynesia</option>
<option value="GA" <?php echo $country == "GA" ? "selected" : "" ?>>Gabon</option>
<option value="GM" <?php echo $country == "GM" ? "selected" : "" ?>>Gambia</option>
<option value="GE" <?php echo $country == "GE" ? "selected" : "" ?>>Georgia</option>
<option value="DE" <?php echo $country == "DE" ? "selected" : "" ?>>Germany</option>
<option value="GH" <?php echo $country == "GH" ? "selected" : "" ?>>Ghana</option>
<option value="GI" <?php echo $country == "GI" ? "selected" : "" ?>>Gibraltar</option>
<option value="GR" <?php echo $country == "GR" ? "selected" : "" ?>>Greece</option>
<option value="GL" <?php echo $country == "GL" ? "selected" : "" ?>>Greenland</option>
<option value="GD" <?php echo $country == "GD" ? "selected" : "" ?>>Grenada</option>
<option value="GP" <?php echo $country == "GP" ? "selected" : "" ?>>Guadeloupe</option>
<option value="GU" <?php echo $country == "GU" ? "selected" : "" ?>>Guam</option>
<option value="GT" <?php echo $country == "GT" ? "selected" : "" ?>>Guatemala</option>
<option value="GN" <?php echo $country == "GN" ? "selected" : "" ?>>Guinea</option>
<option value="GW" <?php echo $country == "GW" ? "selected" : "" ?>>Guinea-Bissau</option>
<option value="GY" <?php echo $country == "GY" ? "selected" : "" ?>>Guyana</option>
<option value="HT" <?php echo $country == "HT" ? "selected" : "" ?>>Haiti</option>
<option value="HN" <?php echo $country == "HN" ? "selected" : "" ?>>Honduras</option>
<option value="HK" <?php echo $country == "HK" ? "selected" : "" ?>>Hong Kong</option>
<option value="HU" <?php echo $country == "HU" ? "selected" : "" ?>>Hungary</option>
<option value="IS" <?php echo $country == "IS" ? "selected" : "" ?>>Iceland</option>
<option value="IN" <?php echo $country == "IN" ? "selected" : "" ?>>India</option>
<option value="ID" <?php echo $country == "ID" ? "selected" : "" ?>>Indonesia</option>
<option value="IR" <?php echo $country == "IR" ? "selected" : "" ?>>Iran (Islamic Republic Of)</option>
<option value="IQ" <?php echo $country == "IQ" ? "selected" : "" ?>>Iraq</option>
<option value="IE" <?php echo $country == "IE" ? "selected" : "" ?>>Ireland</option>
<option value="IL" <?php echo $country == "IL" ? "selected" : "" ?>>Israel</option>
<option value="IT" <?php echo $country == "IT" ? "selected" : "" ?>>Italy</option>
<option value="JM" <?php echo $country == "JM" ? "selected" : "" ?>>Jamaica</option>
<option value="JP" <?php echo $country == "JP" ? "selected" : "" ?>>Japan</option>
<option value="JO" <?php echo $country == "JO" ? "selected" : "" ?>>Jordan</option>
<option value="KZ" <?php echo $country == "KZ" ? "selected" : "" ?>>Kazakhstan</option>
<option value="KE" <?php echo $country == "KE" ? "selected" : "" ?>>Kenya</option>
<option value="KI" <?php echo $country == "KI" ? "selected" : "" ?>>Kiribati</option>
<option value="KP" <?php echo $country == "KP" ? "selected" : "" ?>>Korea North</option>
<option value="KR" <?php echo $country == "KR" ? "selected" : "" ?>>Korea South</option>
<option value="KW" <?php echo $country == "KW" ? "selected" : "" ?>>Kuwait</option>
<option value="KG" <?php echo $country == "KG" ? "selected" : "" ?>>Kyrgyzstan</option>
<option value="LA" <?php echo $country == "LA" ? "selected" : "" ?>>Laos</option>
<option value="LV" <?php echo $country == "LV" ? "selected" : "" ?>>Latvia</option>
<option value="LB" <?php echo $country == "LB" ? "selected" : "" ?>>Lebanon</option>
<option value="LS" <?php echo $country == "LS" ? "selected" : "" ?>>Lesotho</option>
<option value="LR" <?php echo $country == "LR" ? "selected" : "" ?>>Liberia</option>
<option value="LI" <?php echo $country == "LI" ? "selected" : "" ?>>Liechtenstein</option>
<option value="LT" <?php echo $country == "LT" ? "selected" : "" ?>>Lithuania</option>
<option value="LU" <?php echo $country == "LU" ? "selected" : "" ?>>Luxembourg</option>
<option value="MO" <?php echo $country == "MO" ? "selected" : "" ?>>Macau</option>
<option value="MK" <?php echo $country == "MK" ? "selected" : "" ?>>Macedonia</option>
<option value="MG" <?php echo $country == "MG" ? "selected" : "" ?>>Madagascar</option>
<option value="MW" <?php echo $country == "MW" ? "selected" : "" ?>>Malawi</option>
<option value="MY" <?php echo $country == "MY" ? "selected" : "" ?>>Malaysia</option>
<option value="MV" <?php echo $country == "MV" ? "selected" : "" ?>>Maldives</option>
<option value="ML" <?php echo $country == "ML" ? "selected" : "" ?>>Mali</option>
<option value="MT" <?php echo $country == "MT" ? "selected" : "" ?>>Malta</option>
<option value="MH" <?php echo $country == "MH" ? "selected" : "" ?>>Marshall Islands</option>
<option value="MQ" <?php echo $country == "MQ" ? "selected" : "" ?>>Martinique</option>
<option value="MR" <?php echo $country == "MR" ? "selected" : "" ?>>Mauritania</option>
<option value="MU" <?php echo $country == "MU" ? "selected" : "" ?>>Mauritius</option>
<option value="MX" <?php echo $country == "MX" ? "selected" : "" ?>>Mexico</option>
<option value="FM" <?php echo $country == "FM" ? "selected" : "" ?>>Micronesia</option>
<option value="MD" <?php echo $country == "MD" ? "selected" : "" ?>>Moldova</option>
<option value="MC" <?php echo $country == "MC" ? "selected" : "" ?>>Monaco</option>
<option value="MN" <?php echo $country == "MN" ? "selected" : "" ?>>Mongolia</option>
<option value="MS" <?php echo $country == "MS" ? "selected" : "" ?>>Montserrat</option>
<option value="MA" <?php echo $country == "MA" ? "selected" : "" ?>>Morocco</option>
<option value="MZ" <?php echo $country == "MZ" ? "selected" : "" ?>>Mozambique</option>
<option value="NA" <?php echo $country == "NA" ? "selected" : "" ?>>Namibia</option>
<option value="NP" <?php echo $country == "NP" ? "selected" : "" ?>>Nepal</option>
<option value="NL" <?php echo $country == "NL" ? "selected" : "" ?>>Netherlands</option>
<option value="AN" <?php echo $country == "AN" ? "selected" : "" ?>>Netherlands Antilles</option>
<option value="NC" <?php echo $country == "NC" ? "selected" : "" ?>>New Caledonia</option>
<option value="NZ" <?php echo $country == "NZ" ? "selected" : "" ?>>New Zealand</option>
<option value="NI" <?php echo $country == "NI" ? "selected" : "" ?>>Nicaragua</option>
<option value="NE" <?php echo $country == "NE" ? "selected" : "" ?>>Niger</option>
<option value="NG" <?php echo $country == "NG" ? "selected" : "" ?>>Nigeria</option>
<option value="NO" <?php echo $country == "NO" ? "selected" : "" ?>>Norway</option>
<option value="OM" <?php echo $country == "OM" ? "selected" : "" ?>>Oman</option>
<option value="PK" <?php echo $country == "PK" ? "selected" : "" ?>>Pakistan</option>
<option value="PW" <?php echo $country == "PW" ? "selected" : "" ?>>Palau</option>
<option value="PS" <?php echo $country == "PS" ? "selected" : "" ?>>Palestine Autonomous</option>
<option value="PA" <?php echo $country == "PA" ? "selected" : "" ?>>Panama</option>
<option value="PG" <?php echo $country == "PG" ? "selected" : "" ?>>Papua New Guinea</option>
<option value="PY" <?php echo $country == "PY" ? "selected" : "" ?>>Paraguay</option>
<option value="PE" <?php echo $country == "PE" ? "selected" : "" ?>>Peru</option>
<option value="PH" <?php echo $country == "PH" ? "selected" : "" ?>>Philippines</option>
<option value="PL" <?php echo $country == "PL" ? "selected" : "" ?>>Poland</option>
<option value="PT" <?php echo $country == "PT" ? "selected" : "" ?>>Portugal</option>
<option value="PR" <?php echo $country == "PR" ? "selected" : "" ?>>Puerto Rico</option>
<option value="QA" <?php echo $country == "QA" ? "selected" : "" ?>>Qatar</option>
<option value="RE" <?php echo $country == "RE" ? "selected" : "" ?>>Reunion</option>
<option value="RO" <?php echo $country == "RO" ? "selected" : "" ?>>Romania</option>
<option value="RU" <?php echo $country == "RU" ? "selected" : "" ?>>Russian Federation</option>
<option value="RW" <?php echo $country == "RW" ? "selected" : "" ?>>Rwanda</option>
<option value="VC" <?php echo $country == "VC" ? "selected" : "" ?>>Saint Vincent and the Grenadines
</option>
<option value="MP" <?php echo $country == "MP" ? "selected" : "" ?>>Saipan</option>
<option value="SM" <?php echo $country == "SM" ? "selected" : "" ?>>San Marino</option>
<option value="SA" <?php echo $country == "SA" ? "selected" : "" ?>>Saudi Arabia</option>
<option value="SN" <?php echo $country == "SN" ? "selected" : "" ?>>Senegal</option>
<option value="SC" <?php echo $country == "SC" ? "selected" : "" ?>>Seychelles</option>
<option value="SL" <?php echo $country == "SL" ? "selected" : "" ?>>Sierra Leone</option>
<option value="SG" <?php echo $country == "SG" ? "selected" : "" ?>>Singapore</option>
<option value="SK" <?php echo $country == "SK" ? "selected" : "" ?>>Slovak Republic</option>
<option value="SI" <?php echo $country == "SI" ? "selected" : "" ?>>Slovenia</option>
<option value="SO" <?php echo $country == "SO" ? "selected" : "" ?>>Somalia</option>
<option value="ZA" <?php echo $country == "ZA" ? "selected" : "" ?>>South Africa</option>
<option value="ES" <?php echo $country == "ES" ? "selected" : "" ?>>Spain</option>
<option value="LK" <?php echo $country == "LK" ? "selected" : "" ?>>Sri Lanka</option>
<option value="KN" <?php echo $country == "KN" ? "selected" : "" ?>>St. Kitts/Nevis</option>
<option value="LC" <?php echo $country == "LC" ? "selected" : "" ?>>St. Lucia</option>
<option value="SD" <?php echo $country == "SD" ? "selected" : "" ?>>Sudan</option>
<option value="SR" <?php echo $country == "SR" ? "selected" : "" ?>>Suriname</option>
<option value="SZ" <?php echo $country == "SZ" ? "selected" : "" ?>>Swaziland</option>
<option value="SE" <?php echo $country == "SE" ? "selected" : "" ?>>Sweden</option>
<option value="CH" <?php echo $country == "CH" ? "selected" : "" ?>>Switzerland</option>
<option value="SY" <?php echo $country == "SY" ? "selected" : "" ?>>Syria</option>
<option value="TW" <?php echo $country == "TW" ? "selected" : "" ?>>Taiwan</option>
<option value="TI" <?php echo $country == "TI" ? "selected" : "" ?>>Tajikistan</option>
<option value="TZ" <?php echo $country == "TZ" ? "selected" : "" ?>>Tanzania</option>
<option value="TH" <?php echo $country == "TH" ? "selected" : "" ?>>Thailand</option>
<option value="TG" <?php echo $country == "TG" ? "selected" : "" ?>>Togo</option>
<option value="TK" <?php echo $country == "TK" ? "selected" : "" ?>>Tokelau</option>
<option value="TO" <?php echo $country == "TO" ? "selected" : "" ?>>Tonga</option>
<option value="TT" <?php echo $country == "TT" ? "selected" : "" ?>>Trinidad and Tobago</option>
<option value="TN" <?php echo $country == "TN" ? "selected" : "" ?>>Tunisia</option>
<option value="TR" <?php echo $country == "TR" ? "selected" : "" ?>>Turkey</option>
<option value="TM" <?php echo $country == "TM" ? "selected" : "" ?>>Turkmenistan</option>
<option value="TC" <?php echo $country == "TC" ? "selected" : "" ?>>Turks and Caicos Islands</option>
<option value="TV" <?php echo $country == "TV" ? "selected" : "" ?>>Tuvalu</option>
<option value="UG" <?php echo $country == "UG" ? "selected" : "" ?>>Uganda</option>
<option value="UA" <?php echo $country == "UA" ? "selected" : "" ?>>Ukraine</option>
<option value="AE" <?php echo $country == "AE" ? "selected" : "" ?>>United Arab Emirates</option>
<option value="UY" <?php echo $country == "UY" ? "selected" : "" ?>>Uruguay</option>
<option value="UZ" <?php echo $country == "UZ" ? "selected" : "" ?>>Uzbekistan</option>
<option value="VU" <?php echo $country == "VU" ? "selected" : "" ?>>Vanuatu</option>
<option value="VE" <?php echo $country == "VE" ? "selected" : "" ?>>Venezuela</option>
<option value="VN" <?php echo $country == "VN" ? "selected" : "" ?>>Viet Nam</option>
<option value="VG" <?php echo $country == "VG" ? "selected" : "" ?>>Virgin Islands (British)</option>
<option value="VI" <?php echo $country == "VI" ? "selected" : "" ?>>Virgin Islands (U.S.)</option>
<option value="WF" <?php echo $country == "WF" ? "selected" : "" ?>>Wallis and Futuna Islands</option>
<option value="YE" <?php echo $country == "YE" ? "selected" : "" ?>>Yemen</option>
<option value="YU" <?php echo $country == "YU" ? "selected" : "" ?>>Yugoslavia</option>
<option value="ZM" <?php echo $country == "ZM" ? "selected" : "" ?>>Zambia</option>
<option value="ZW" <?php echo $country == "ZW" ? "selected" : "" ?>>Zimbabwe</option>